/*
 * TgsbSettingsActivity — Voice preset picker for TGSpeechBox TTS.
 *
 * License: GPL-3.0
 */

package com.tgspeechbox.tts

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.view.View
import android.widget.TextView

class TgsbSettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(
            TgsbTtsService.PREFS_NAME, MODE_PRIVATE
        )
        val currentPreset = prefs.getString(
            TgsbTtsService.PREF_VOICE_PRESET,
            TgsbTtsService.DEFAULT_PRESET
        ) ?: TgsbTtsService.DEFAULT_PRESET

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "Voice"
            textSize = 20f
            val bot = (16 * resources.displayMetrics.density).toInt()
            setPadding(0, 0, 0, bot)
        }
        layout.addView(title)

        val radioGroup = RadioGroup(this)

        for (vd in TgsbTtsService.VOICES) {
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = vd.label
                tag = vd.id
                textSize = 18f
                val vert = (8 * resources.displayMetrics.density).toInt()
                setPadding(paddingLeft, vert, paddingRight, vert)
                isChecked = (vd.id == currentPreset)
            }
            radioGroup.addView(rb)
        }

        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            val rb = group.findViewById<RadioButton>(checkedId)
            val presetId = rb?.tag as? String ?: return@setOnCheckedChangeListener
            prefs.edit()
                .putString(TgsbTtsService.PREF_VOICE_PRESET, presetId)
                .apply()
        }

        layout.addView(radioGroup)
        setContentView(layout)
    }
}
