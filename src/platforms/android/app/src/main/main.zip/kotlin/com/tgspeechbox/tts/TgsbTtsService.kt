/*
 * TgsbTtsService — Android TextToSpeechService backed by TGSpeechBox.
 *
 * Pipeline: text → eSpeak IPA → nvspFrontend → speechPlayer → PCM
 *
 * License: GPL-3.0 (links eSpeak-ng GPL)
 */

package com.tgspeechbox.tts

import android.content.res.AssetManager
import android.media.AudioFormat
import android.speech.tts.SynthesisCallback
import android.speech.tts.SynthesisRequest
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeechService
import android.speech.tts.Voice
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale

class TgsbTtsService : TextToSpeechService() {

    companion object {
        private const val TAG = "TgsbTTS"
        private const val SAMPLE_RATE = 22050

        init {
            System.loadLibrary("tgspeechbox_jni")
        }

        /** Voice presets — timbre only, independent of language */
        private data class VoiceDef(val id: String, val label: String)

        private val VOICES = listOf(
            VoiceDef("tgsb-adam",     "Adam"),
            VoiceDef("tgsb-benjamin", "Benjamin"),
            VoiceDef("tgsb-caleb",    "Caleb"),
            VoiceDef("tgsb-david",    "David"),
            VoiceDef("tgsb-robert",   "Robert"),
        )

        private val VOICE_IDS = VOICES.map { it.id }.toSet()

        /**
         * Language mapping: Android ISO-639-3 lang + ISO-3166 country
         * → eSpeak language tag + tgsb lang pack name.
         */
        private data class LangDef(
            val iso3Lang: String,       // Android 3-letter lang (eng, fra, deu ...)
            val iso3Country: String,    // Android 3-letter country ("" = any)
            val espeakLang: String,     // eSpeak voice language tag
            val tgsbLang: String,       // nvspFrontend language pack
            val displayLocale: Locale   // for Voice API
        )

        private val LANGUAGES = listOf(
            // English
            LangDef("eng", "USA", "en-us", "en-us", Locale("en", "US")),
            LangDef("eng", "GBR", "en-gb", "en-gb", Locale("en", "GB")),
            LangDef("eng", "CAN", "en",    "en-ca", Locale("en", "CA")),
            LangDef("eng", "",    "en-us", "en-us", Locale("en", "US")), // fallback

            // Romance
            LangDef("fra", "",    "fr",    "fr",    Locale("fr")),
            LangDef("spa", "MEX", "es-mx", "es-mx", Locale("es", "MX")),
            LangDef("spa", "",    "es",    "es",    Locale("es")),
            LangDef("ita", "",    "it",    "it",    Locale("it")),
            LangDef("por", "BRA", "pt-br", "pt-br", Locale("pt", "BR")),
            LangDef("por", "PRT", "pt",    "pt-pt", Locale("pt", "PT")),
            LangDef("por", "",    "pt",    "pt",    Locale("pt")),
            LangDef("ron", "",    "ro",    "ro",    Locale("ro")),

            // Germanic
            LangDef("deu", "",    "de",    "de",    Locale("de")),
            LangDef("nld", "",    "nl",    "nl",    Locale("nl")),
            LangDef("dan", "",    "da",    "da",    Locale("da")),
            LangDef("swe", "",    "sv",    "sv",    Locale("sv")),

            // Slavic
            LangDef("pol", "",    "pl",    "pl",    Locale("pl")),
            LangDef("ces", "",    "cs",    "cs",    Locale("cs")),
            LangDef("slk", "",    "sk",    "sk",    Locale("sk")),
            LangDef("bul", "",    "bg",    "bg",    Locale("bg")),
            LangDef("hrv", "",    "hr",    "hr",    Locale("hr")),
            LangDef("rus", "",    "ru",    "ru",    Locale("ru")),
            LangDef("ukr", "",    "uk",    "uk",    Locale("uk")),

            // Uralic
            LangDef("hun", "",    "hu",    "hu",    Locale("hu")),
            LangDef("fin", "",    "fi",    "fi",    Locale("fi")),

            // Other
            LangDef("zho", "",    "cmn",   "zh",    Locale("zh")),
        )

        /** Unique base languages (for LANG_AVAILABLE matching) */
        private val SUPPORTED_LANGS = LANGUAGES.map { it.iso3Lang }.toSet()

        /** (lang, country) pairs that match LANG_COUNTRY_AVAILABLE */
        private val SUPPORTED_PAIRS = LANGUAGES
            .filter { it.iso3Country.isNotEmpty() }
            .map { it.iso3Lang to it.iso3Country }
            .toSet()

        /** Look up the best LangDef for a given locale */
        private fun findLangDef(lang: String, country: String): LangDef? {
            // Try exact (lang + country) match first
            if (country.isNotEmpty()) {
                LANGUAGES.find { it.iso3Lang == lang && it.iso3Country == country }
                    ?.let { return it }
            }
            // Fall back to lang-only entry (iso3Country == "")
            return LANGUAGES.find { it.iso3Lang == lang && it.iso3Country.isEmpty() }
        }
    }

    @Volatile
    private var stopRequested = false
    private var nativeHandle: Long = 0L
    private var currentVoice: VoiceDef = VOICES[0]
    private var currentLang: LangDef = LANGUAGES[0] // en-us default

    // JNI declarations
    private external fun nativeCreate(
        espeakDataPath: String, packDirPath: String, sampleRate: Int
    ): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeSetVoice(handle: Long, voiceName: String)
    private external fun nativeQueueText(
        handle: Long, text: String, speechRate: Int, pitch: Int
    )
    private external fun nativePullAudio(
        handle: Long, outBuffer: ByteArray, maxBytes: Int
    ): Int
    private external fun nativeStop(handle: Long)
    private external fun nativeSetLanguage(
        handle: Long, espeakLang: String, tgsbLang: String
    )

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "onCreate: extracting assets and initializing engine")

        extractAssets()

        val espeakDataPath = filesDir.absolutePath
        val packDirPath = File(filesDir, "tgsb").absolutePath

        nativeHandle = nativeCreate(espeakDataPath, packDirPath, SAMPLE_RATE)
        if (nativeHandle == 0L) {
            Log.e(TAG, "Failed to create native engine")
        } else {
            Log.i(TAG, "Native engine created (handle=$nativeHandle)")
        }
    }

    override fun onDestroy() {
        if (nativeHandle != 0L) {
            nativeDestroy(nativeHandle)
            nativeHandle = 0L
        }
        super.onDestroy()
    }

    // ---- Asset extraction ----

    private fun extractAssets() {
        // Bump this version when assets change to force re-extraction
        val assetVersion = 3
        val marker = File(filesDir, ".assets_v$assetVersion")
        if (marker.exists()) return

        // Clean old markers and stale data
        filesDir.listFiles()?.filter { it.name.startsWith(".assets_") }?.forEach { it.delete() }
        File(filesDir, "espeak-ng-data").deleteRecursively()
        File(filesDir, "tgsb").deleteRecursively()

        Log.i(TAG, "Extracting assets to ${filesDir.absolutePath}")
        copyAssetsDir("espeak-ng-data", File(filesDir, "espeak-ng-data"))
        copyAssetsDir("tgsb", File(filesDir, "tgsb"))
        marker.createNewFile()
    }

    private fun copyAssetsDir(assetPath: String, targetDir: File) {
        val assetMgr = assets
        val entries = assetMgr.list(assetPath) ?: return

        if (entries.isEmpty()) {
            // It's a file, not a directory
            copyAssetFile(assetMgr, assetPath, targetDir)
            return
        }

        targetDir.mkdirs()
        for (entry in entries) {
            val childAsset = "$assetPath/$entry"
            val childTarget = File(targetDir, entry)
            val subEntries = assetMgr.list(childAsset)
            if (subEntries != null && subEntries.isNotEmpty()) {
                copyAssetsDir(childAsset, childTarget)
            } else {
                copyAssetFile(assetMgr, childAsset, childTarget)
            }
        }
    }

    private fun copyAssetFile(assetMgr: AssetManager, assetPath: String, target: File) {
        try {
            target.parentFile?.mkdirs()
            assetMgr.open(assetPath).use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output)
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "Failed to copy asset $assetPath: ${e.message}")
        }
    }

    // ---- Locale-based API (required abstract methods) ----

    override fun onIsLanguageAvailable(lang: String, country: String, variant: String): Int {
        if (lang !in SUPPORTED_LANGS) return TextToSpeech.LANG_NOT_SUPPORTED
        if (country.isNotEmpty() && (lang to country) in SUPPORTED_PAIRS)
            return TextToSpeech.LANG_COUNTRY_AVAILABLE
        return TextToSpeech.LANG_AVAILABLE
    }

    override fun onLoadLanguage(lang: String, country: String, variant: String): Int {
        val availability = onIsLanguageAvailable(lang, country, variant)
        if (availability == TextToSpeech.LANG_NOT_SUPPORTED) return availability

        val ld = findLangDef(lang, country) ?: return TextToSpeech.LANG_NOT_SUPPORTED
        currentLang = ld
        if (nativeHandle != 0L) {
            nativeSetLanguage(nativeHandle, ld.espeakLang, ld.tgsbLang)
            Log.i(TAG, "Language loaded: ${ld.espeakLang} / ${ld.tgsbLang}")
        }
        return availability
    }

    override fun onGetLanguage(): Array<String> {
        return arrayOf(currentLang.iso3Lang, currentLang.iso3Country, "")
    }

    // ---- Voice API (API 21+) ----

    override fun onGetVoices(): List<Voice> {
        // Each voice preset available for the primary locale (en-US).
        // Language is set independently via the SynthesisRequest.
        return VOICES.map { vd ->
            Voice(
                vd.id,
                Locale("en", "US"),
                Voice.QUALITY_VERY_HIGH,
                Voice.LATENCY_NORMAL,
                false,
                emptySet()
            )
        }
    }

    override fun onIsValidVoiceName(voiceName: String): Int {
        return if (voiceName in VOICE_IDS) TextToSpeech.SUCCESS
               else TextToSpeech.ERROR
    }

    override fun onLoadVoice(voiceName: String): Int {
        if (onIsValidVoiceName(voiceName) != TextToSpeech.SUCCESS)
            return TextToSpeech.ERROR
        loadVoiceByName(voiceName)
        return TextToSpeech.SUCCESS
    }

    override fun onGetDefaultVoiceNameFor(
        lang: String, country: String, variant: String
    ): String {
        return "tgsb-adam"
    }

    private fun loadVoiceByName(voiceName: String) {
        val vd = VOICES.find { it.id == voiceName } ?: return
        currentVoice = vd
        if (nativeHandle != 0L) {
            val presetName = vd.id.removePrefix("tgsb-")
            nativeSetVoice(nativeHandle, presetName)
        }
    }

    // ---- Synthesis ----

    override fun onSynthesizeText(request: SynthesisRequest, callback: SynthesisCallback) {
        stopRequested = false

        if (nativeHandle == 0L) {
            Log.e(TAG, "Engine not initialized")
            callback.error(TextToSpeech.ERROR_SYNTHESIS)
            return
        }

        // Read language from the request (RHVoice pattern — onLoadLanguage
        // is never called by TalkBack, but the request always carries locale).
        val reqLang = request.language ?: ""
        val reqCountry = request.country ?: ""
        if (reqLang.isNotEmpty()) {
            val ld = findLangDef(reqLang, reqCountry)
            if (ld != null && ld != currentLang) {
                currentLang = ld
                if (nativeHandle != 0L) {
                    nativeSetLanguage(nativeHandle, ld.espeakLang, ld.tgsbLang)
                    Log.i(TAG, "Language from request: $reqLang-$reqCountry → ${ld.espeakLang}/${ld.tgsbLang}")
                }
            }
        }

        // Load requested voice (timbre only; language already set above)
        val voiceName = request.voiceName
        if (!voiceName.isNullOrEmpty()) {
            onLoadVoice(voiceName)
        }

        // Start audio stream
        val ret = callback.start(
            SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1
        )
        if (ret != TextToSpeech.SUCCESS) {
            callback.error(TextToSpeech.ERROR_SYNTHESIS)
            return
        }

        // Get text
        val text = request.charSequenceText?.toString()
            ?: request.text
            ?: ""
        if (text.isEmpty()) {
            callback.done()
            return
        }

        // Queue text through pipeline (fast: eSpeak IPA + frontend frames)
        try {
            nativeQueueText(nativeHandle, text, request.speechRate, request.pitch)
        } catch (e: Exception) {
            Log.e(TAG, "Queue failed: ${e.message}")
            callback.error(TextToSpeech.ERROR_SYNTHESIS)
            return
        }

        // Stream PCM as it's synthesized — audio starts playing immediately
        val buf = ByteArray(8192) // ~93ms at 22050Hz s16le
        var totalBytes = 0
        while (!stopRequested) {
            val n = nativePullAudio(nativeHandle, buf, buf.size)
            if (n <= 0) break
            val writeResult = callback.audioAvailable(buf, 0, n)
            if (writeResult != TextToSpeech.SUCCESS) {
                callback.error(TextToSpeech.ERROR_OUTPUT)
                return
            }
            totalBytes += n
        }

        if (stopRequested) {
            callback.error(TextToSpeech.ERROR_SERVICE)
            return
        }

        callback.done()
    }

    override fun onStop() {
        stopRequested = true
        if (nativeHandle != 0L) {
            nativeStop(nativeHandle)
        }
    }
}
